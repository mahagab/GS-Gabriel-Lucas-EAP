package dominio;

public enum Status {

	LIBERADO,
	BLOQUEADO
	
}
