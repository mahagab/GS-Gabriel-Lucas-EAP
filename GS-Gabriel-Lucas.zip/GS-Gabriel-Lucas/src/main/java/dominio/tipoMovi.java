package dominio;

public enum tipoMovi {

	ENTROU,
	SAIU
	
}
